from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session


class Base(DeclarativeBase):
    pass


# TODO: crie a engine apontando para sqlite:///biblioteca.db.
DATABASE = "sqlite:///biblioteca.db"
engine = create_engine(DATABASE)

def criar_banco():
    Base.metadata.create_all(bind=engine)
    # TODO: crie as tabelas usando Base.metadata.create_all(bind=engine).
    pass


def nova_sessao():
    return Session(bind=engine)
    # TODO: devolva uma Session ligada à engine.


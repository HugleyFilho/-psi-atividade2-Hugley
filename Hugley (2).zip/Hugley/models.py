from typing import List

from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base

class Autor(Base):
    __tablename__ = 'autores'

    id:Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    nome:Mapped[str] = mapped_column(String(30), unique=True)
    pais:Mapped[str] = mapped_column(String(30))

    livros:Mapped[List["Livro"]] = relationship(back_populates='autor') 

class Livro(Base):
    id:Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    titulo:Mapped[str] = mapped_column(nullable=False, unique=True)
    ano:Mapped[int] = mapped_column(nullable=False)
    autor_id: Mapped[int] = mapped_column(ForeignKey("users.id"))

    autor: Mapped["Autor"] = relationship(back_populates="livro")


from models import Autor, Livro
from database import nova_sessao

def popular_banco(session):
    with session as session:
        try:
            autor1 = Autor(nome="José de Alencar", país="Brasil")
            autor2 = Autor(nome="Cecília Meireles", país="Brasil")
            autor3 = Autor(nome="Machado de Asis", país="Brasil")
            session.add_all([autor1, autor2, autor3])

            livro1 = Livro(titulo="O Guarani", ano=1857, autor_id=1)
            livro2 = Livro(titulo="Iracema", ano=1865, autor_id=1)
            livro3 = Livro(titulo="Viagem", ano=1939, autor_id=2)
            livro4 = Livro(titulo="Antologia Poética", ano=1963, autor_id=2)
            livro5 = Livro(titulo="Memórias Póstumas de Brás Cubas", ano=1881, autor_id=3)
            livro6 = Livro(titulo="Dom Casmurro", ano=1899, autor_id=3)
            session.add_all([livro1, livro2, livro3, livro4, livro5, livro6])

            session.commit()
        except Exception:
            session.rollback()
    # TODO: crie pelo menos 3 autores e 6 livros.
    # TODO: relacione os livros aos autores.
    # TODO: use session.add ou session.add_all e session.commit.

